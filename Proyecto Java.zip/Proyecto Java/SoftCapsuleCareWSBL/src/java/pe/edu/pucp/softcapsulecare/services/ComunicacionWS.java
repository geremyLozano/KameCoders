package pe.edu.pucp.softcapsulecare.services;

import jakarta.jws.WebService;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import java.util.ArrayList;
import java.util.Date;
import pe.edu.pucp.citamedica.dao.ComunicacionDAO;
import pe.edu.pucp.citamedica.model.comunicacion.Comunicacion;
import pe.edu.pucp.citamedica.model.comunicacion.TipoComunicacion;
import pe.edu.pucp.citamedica.model.comunicacion.EstadoComunicacion;
import pe.edu.pucp.citamedica.mysql.ComunicacionMySQL;

@WebService(serviceName = "ComunicacionWS")
public class ComunicacionWS {

    private final ComunicacionDAO comunicacionDAO;

    public ComunicacionWS() {
        this.comunicacionDAO = new ComunicacionMySQL();
    }
    

  @WebMethod(operationName = "insertarComunicacion")
public int insertarComunicacion(
        @WebParam(name = "tipo") String tipo,
        @WebParam(name = "contenido") String contenido,
        @WebParam(name = "fechaComunicacion") java.util.Date fechaComunicacion,
        @WebParam(name = "idPaciente") int idPaciente) {

    try {
        TipoComunicacion tipoSeleccionado;

        // Convertir el string en el enum correspondiente
        switch (tipo.toLowerCase()) {
            case "queja":
                tipoSeleccionado = TipoComunicacion.Queja;
                break;
            case "sugerencia":
                tipoSeleccionado = TipoComunicacion.Sugerencia;
                break;
            default:
                System.err.println("Error: Tipo de comunicación no válido - " + tipo);
                return 0;
        }

        // Crear la comunicación
        Comunicacion comunicacion = new Comunicacion();
        comunicacion.setTipo(tipoSeleccionado);
        comunicacion.setContenido(contenido);
        comunicacion.setFechaComunicacion(fechaComunicacion);
        comunicacion.setIdPaciente(idPaciente);
        comunicacion.setEstado(EstadoComunicacion.RECIBIDA);
        comunicacion.setRespuesta("RESPUESTA PENDIENTE");

        return comunicacionDAO.insertar(comunicacion);

    } catch (Exception e) {
        System.err.println("Error al insertar comunicación: " + e.getMessage());
        return 0;
    }
}




    // Método para modificar el estado y la respuesta de una comunicación
    @WebMethod(operationName = "modificarComunicacion")
    public int modificarComunicacion(@WebParam(name = "idComunicacion") int idComunicacion,
                                     @WebParam(name = "estado") String nuevoEstado,
                                     @WebParam(name = "respuesta") String respuesta) {
        try {
            Comunicacion comunicacion = comunicacionDAO.obtenerPorId(idComunicacion);
            if (comunicacion != null) {
                comunicacion.setEstado(EstadoComunicacion.valueOf(nuevoEstado.toUpperCase()));
                comunicacion.setRespuesta(respuesta);
                return comunicacionDAO.modificar(comunicacion);
            }
        } catch (Exception e) {
            System.err.println("Error al modificar comunicación: " + e.getMessage());
        }
        return 0;
    }

    // Método para eliminar una comunicación por ID
    @WebMethod(operationName = "eliminarComunicacion")
    public int eliminarComunicacion(@WebParam(name = "idComunicacion") int idComunicacion) {
        try {
            return comunicacionDAO.eliminar(idComunicacion);
        } catch (Exception e) {
            System.err.println("Error al eliminar comunicación: " + e.getMessage());
            return 0;
        }
    }

    @WebMethod(operationName = "listarTodasLasComunicaciones")
    public ArrayList<Comunicacion> listarTodasLasComunicaciones() {
        // Forzar a que obtenga datos frescos cada vez que se llama al método
        return new ComunicacionMySQL().listarTodos();
    }

    @WebMethod(operationName = "listarComunicacionesPaciente")
    public ArrayList<Comunicacion> listarComunicacionesPaciente(@WebParam(name = "idPaciente") int idPaciente) {
        try {
            System.out.println("Invocación recibida para idPaciente: " + idPaciente);
            ArrayList<Comunicacion> resultado = comunicacionDAO.listarPorPaciente(idPaciente);
            System.out.println("Número de comunicaciones encontradas: " + resultado.size());
            return resultado;
        } catch (Exception e) {
            System.err.println("Error en listarComunicacionesPaciente: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();
        }
    }


    // Método para listar comunicaciones por estado
    @WebMethod(operationName = "listarComunicacionesPorEstado")
    public ArrayList<Comunicacion> listarComunicacionesPorEstado(@WebParam(name = "estado") String estado) {
        try {
            ArrayList<Comunicacion> todas = comunicacionDAO.listarTodos();
            ArrayList<Comunicacion> filtradas = new ArrayList<>();
            for (Comunicacion com : todas) {
                if (com.getEstado().name().equalsIgnoreCase(estado)) {
                    filtradas.add(com);
                }
            }
            return filtradas;
        } catch (Exception e) {
            System.err.println("Error al listar comunicaciones por estado: " + e.getMessage());
            return new ArrayList<>();
        }
        
        
    }
    
    @WebMethod(operationName = "listarComunicacionesFiltradas")
    public ArrayList<Comunicacion> listarComunicacionesFiltradas(
        @WebParam(name = "tipo") String tipo,
        @WebParam(name = "estado") String estado,
        @WebParam(name = "fechaInicio") Date fechaInicio,
        @WebParam(name = "fechaFin") Date fechaFin,
        @WebParam(name = "idPaciente") Integer idPaciente) {

        // Llama al método del DAO para obtener la lista filtrada
        return comunicacionDAO.listarComunicacionesFiltradas(tipo, estado, fechaInicio, fechaFin, idPaciente);
    }
    
    /**
     * WebMethod para obtener el conteo de comunicaciones por estado.
     * Devuelve un ArrayList de String[] donde:
     * - Elemento [0] = Estado de la comunicación (Recibido, EnProceso, Resuelto)
     * - Elemento [1] = Conteo de comunicaciones para ese estado
     */
    @WebMethod(operationName = "obtenerConteoPorEstado")
    public ArrayList<String[]> obtenerConteoPorEstado() {
        ArrayList<String[]> conteoPorEstado = new ArrayList<>();
        try {
            // Llamar al método del DAO para obtener el conteo por estado
            conteoPorEstado = comunicacionDAO.obtenerConteoPorEstado();

            // Imprimir el resultado para verificar en el servidor
            for (String[] conteo : conteoPorEstado) {
                System.out.println("Estado: " + conteo[0] + ", Conteo: " + conteo[1]);
            }
        } catch (Exception e) {
            System.err.println("Error al obtener conteo por estado: " + e.getMessage());
        }
        return conteoPorEstado;
    }
    
    
}
