package pe.edu.pucp.citamedica.model.clinica;
public enum TipoAmbiente {
    Laboratorio, Consultorio
}
