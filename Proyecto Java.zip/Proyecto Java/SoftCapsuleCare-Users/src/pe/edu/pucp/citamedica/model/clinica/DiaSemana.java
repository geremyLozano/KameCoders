package pe.edu.pucp.citamedica.model.clinica;

public enum DiaSemana {
    Lunes, Martes, Miercoles, Jueves, Viernes, Sabado, Domingo
}
