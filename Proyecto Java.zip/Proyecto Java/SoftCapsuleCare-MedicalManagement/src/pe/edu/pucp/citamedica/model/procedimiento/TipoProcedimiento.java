package pe.edu.pucp.citamedica.model.procedimiento;

public enum TipoProcedimiento {
    Evaluacion_por_imagenes,Laboratorio,Chequeo_general
}
