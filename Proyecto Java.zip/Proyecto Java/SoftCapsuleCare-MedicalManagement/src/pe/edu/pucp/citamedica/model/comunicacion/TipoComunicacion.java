package pe.edu.pucp.citamedica.model.comunicacion;

public enum TipoComunicacion {
    Queja, Sugerencia
}
