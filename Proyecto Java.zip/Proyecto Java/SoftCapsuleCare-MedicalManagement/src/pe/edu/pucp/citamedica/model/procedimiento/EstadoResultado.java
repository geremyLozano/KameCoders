package pe.edu.pucp.citamedica.model.procedimiento;

public enum EstadoResultado {
    Completado, Pendiente, Inconcluso
}
