package pe.edu.pucp.citamedica.model.consultas;

public enum EstadoCita {
    Pendiente,Confirmada,Cancelada,Reprogramada,En_progreso,Completada,No_asistio, ASISTIDA
}
