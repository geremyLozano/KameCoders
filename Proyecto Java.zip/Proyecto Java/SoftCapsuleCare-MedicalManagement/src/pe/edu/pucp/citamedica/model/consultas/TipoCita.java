package pe.edu.pucp.citamedica.model.consultas;

public enum TipoCita {
    Presencial, Virtual, NO_ASIGNADO 
}
